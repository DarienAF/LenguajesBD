-- --- ------ ------ ----CURSORES ----- ----- ------- -----
-- KEISY --
--1. Cursor para listar las ventas
DECLARE
    CURSOR cur_ventas IS
        SELECT id_venta, cantidad, total, fecha
        FROM Ventas;
BEGIN
    FOR venta IN cur_ventas LOOP
        DBMS_OUTPUT.PUT_LINE('Venta ID: ' || venta.id_venta || 
                             ' - Cantidad: ' || venta.cantidad || 
                             ' - Total: ' || venta.total || 
                             ' - Fecha: ' || venta.fecha);
    END LOOP;
END;
/


--2. Cursor para listar los servicios
DECLARE
    CURSOR cur_servicios IS
        SELECT id_servicio, servicio 
        FROM Servicios;
BEGIN
    FOR servicio IN cur_servicios LOOP
        DBMS_OUTPUT.PUT_LINE('Servicio ID: ' || servicio.id_servicio || 
                             ' - Nombre: ' || servicio.servicio);
    END LOOP;
END;
/



-- JOHEL --
--3. Cursor para listar todos los clientes
DECLARE
    CURSOR cur_clientes IS
        SELECT * FROM Clientes;
BEGIN
    FOR cliente IN cur_clientes LOOP
        DBMS_OUTPUT.PUT_LINE(cliente.id_cliente || ' - ' || cliente.nombre_cliente);
    END LOOP;
END;
/

--4. Cursor para listar todas las categorías
DECLARE
    CURSOR cur_categorias IS
        SELECT * FROM Categorias;
BEGIN
    FOR categoria IN cur_categorias LOOP
        DBMS_OUTPUT.PUT_LINE(categoria.id_categoria || ' - ' || categoria.nombre_categoria);
    END LOOP;
END;
/

--Juan Carlos--
--5. Cursor para listar todas las ocupaciones
DECLARE
    CURSOR c_ocupaciones IS
        SELECT id_ocupacion, nombre_ocupacion, cantidad_empleados
        FROM Ocupaciones;
    v_ocupacion c_ocupaciones%ROWTYPE;
BEGIN
    OPEN c_ocupaciones;
    LOOP
        FETCH c_ocupaciones INTO v_ocupacion;
        EXIT WHEN c_ocupaciones%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('ID: ' || v_ocupacion.id_ocupacion || ', Nombre: ' || v_ocupacion.nombre_ocupacion || ', Empleados: ' || v_ocupacion.cantidad_empleados);
    END LOOP;
    CLOSE c_ocupaciones;
END;
/

--6. Cursor para listar productos de un proveedor específico
DECLARE
    CURSOR c_productos_proveedor IS
        SELECT id_producto, nombre_producto, inventario
        FROM Productos
        WHERE id_proveedor = 1; -- Cambiar por el ID del proveedor que desees consultar
    v_producto c_productos_proveedor%ROWTYPE;
BEGIN
    OPEN c_productos_proveedor;
    LOOP
        FETCH c_productos_proveedor INTO v_producto;
        EXIT WHEN c_productos_proveedor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('ID: ' || v_producto.id_producto || ', Nombre: ' || v_producto.nombre_producto || ', Inventario: ' || v_producto.inventario);
    END LOOP;
    CLOSE c_productos_proveedor;
END;
/


-- --- ------ ------ -----TRIGGER ----- ----- ------- -----
-- KEISY --
-- 1. Trigger para actualizar la fecha
CREATE OR REPLACE TRIGGER trg_actualizar_ventas
AFTER UPDATE ON ventas
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Venta con ID ' || :OLD.id_venta || ' ha sido actualizada.');
END;
/


-- JOHEL --
-- 2. Trigger para registrar la fecha de actualización
CREATE OR REPLACE TRIGGER trg_auditar_actualizaciones_empleados
AFTER UPDATE ON Empleados
FOR EACH ROW
BEGIN
    -- Registro de la actualizaci n en la salida DBMS (se puede modificar seg n necesidades)
    DBMS_OUTPUT.PUT_LINE('Empleado actualizado: ID = ' || :OLD.id_empleado || ', Nombre = ' || :OLD.nombre_empleado || ', Apellido = ' || :OLD.apellido);
END;
/


--Juan Carlos--
--3. Trigger para auditar inventario después de eliminar un producto
CREATE OR REPLACE TRIGGER actualizar_inventario
AFTER DELETE ON Productos
FOR EACH ROW
BEGIN
    -- Registro en la salida de DBMS_OUTPUT para fines de auditor a
    DBMS_OUTPUT.PUT_LINE('Producto eliminado - ID: ' || :OLD.id_producto || ', Inventario eliminado: ' || :OLD.inventario || ', Categor a ID: ' || :OLD.id_categoria);
END;
/

--Darien Aguilar--
-- 4. Un trigger para evitar numeros negativos en salarioso
CREATE OR REPLACE TRIGGER TGR_SALARY_EMPLEADOS
BEFORE INSERT ON EMPLEADOS
FOR EACH ROW
    BEGIN
        IF :NEW.salario < 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'El salario es negativo, cambielo a uno valido');
        END IF;
    END;
/
-- 6. Un trigger para el formato de correo en proveedores
CREATE OR REPLACE TRIGGER TGR_CORREO_PROVEEDORES
BEFORE INSERT OR UPDATE ON PROVEEDOR
FOR EACH ROW
    BEGIN
        IF :NEW.correo NOT LIKE '%_@_%._%' THEN
            RAISE_APPLICATION_ERROR(-20002, 'Formato de correo incorrecto');
        END IF;
    END;
/