/*------------------------FUNCIONES--------------------------*/
-- JUAN CARLOS
-- 1. Funci�n para obtener el nombre de una categor�a por ID
CREATE OR REPLACE FUNCTION obtener_nombre_categoria(
    p_id_categoria IN NUMBER
) RETURN VARCHAR2 IS
    v_nombre_categoria VARCHAR2(100);
BEGIN
    SELECT nombre_categoria INTO v_nombre_categoria
    FROM Categorias
    WHERE id_categoria = p_id_categoria;
    
    RETURN v_nombre_categoria;
END;
/
-- 2. Funci�n para contar el n�mero de clientes
CREATE OR REPLACE FUNCTION contar_clientes RETURN NUMBER IS
    v_num_clientes NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_num_clientes
    FROM Clientes;
    
    RETURN v_num_clientes;
END;
/

-- 3. Funci�n para obtener el nombre de un empleado por ID
CREATE OR REPLACE FUNCTION obtener_nombre_empleado(
    p_id_empleado IN NUMBER
) RETURN VARCHAR2 IS
    v_nombre_empleado VARCHAR2(100);
BEGIN
    SELECT nombre_empleado INTO v_nombre_empleado
    FROM Empleados
    WHERE id_empleado = p_id_empleado;
    
    RETURN v_nombre_empleado;
END;
/

-- 4. Funci�n para obtener el salario total de todos los empleados
CREATE OR REPLACE FUNCTION obtener_salario_total RETURN NUMBER IS
    v_salario_total NUMBER;
BEGIN
    SELECT SUM(salario) INTO v_salario_total
    FROM Empleados;
    
    RETURN v_salario_total;
END;
/

-- 5. Funci�n para obtener el nombre de un proveedor por ID
CREATE OR REPLACE FUNCTION obtener_nombre_proveedor(
    p_id_proveedor IN NUMBER
) RETURN VARCHAR2 IS
    v_nombre_proveedor VARCHAR2(100);
BEGIN
    SELECT nombre_proveedor INTO v_nombre_proveedor
    FROM Proveedor
    WHERE id_proveedor = p_id_proveedor;
    
    RETURN v_nombre_proveedor;
END;
/
--KEISY
--6. Devuelve el total de ventas de un cliente especifico 
CREATE OR REPLACE FUNCTION obtener_total_ventas_cliente(
    p_cliente_id IN NUMBER
) RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    SELECT SUM(monto)
    INTO v_total
    FROM ventas
    WHERE cliente_id = p_cliente_id;

    RETURN NVL(v_total, 0);
END;

--7. Devuelve el total de servicios asociados a una reservacion
CREATE OR REPLACE FUNCTION calcular_total_servicios_reservacion(
    p_reservacion_id IN NUMBER
) RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    SELECT SUM(costo)
    INTO v_total
    FROM servicios
    WHERE reservacion_id = p_reservacion_id;

    RETURN NVL(v_total, 0);
END;

--8. Obtener fecha la fecha de una venta
CREATE OR REPLACE FUNCTION obtener_fecha_venta_cliente(
    p_cliente_id IN NUMBER
) RETURN DATE IS
    v_fecha DATE;
BEGIN
    SELECT MAX(fecha_venta)
    INTO v_fecha
    FROM ventas
    WHERE cliente_id = p_cliente_id;

    RETURN v_fecha;
END;

--9. Calcular el promedio de ventas por cliente
CREATE OR REPLACE FUNCTION calcular_promedio_ventas_cliente(
    p_cliente_id IN NUMBER
) RETURN NUMBER IS
    v_promedio NUMBER;
BEGIN
    SELECT AVG(monto)
    INTO v_promedio
    FROM ventas
    WHERE cliente_id = p_cliente_id;

    RETURN NVL(v_promedio, 0);
END;

--10. Obtener las reservaciones de un cliente por su id
CREATE OR REPLACE FUNCTION TOTAL_RESERVACIONES_CLIENTE(p_cliente_id IN NUMBER)
RETURN NUMBER IS
    v_total_reservaciones NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_total_reservaciones
    FROM RESERVACIONES
    WHERE CLIENTE_ID = p_cliente_id;

    RETURN v_total_reservaciones;
END;
/
--JUAN CARLOS--
--11.Funcion que devuelve el nombre de una ocupación dado su ID
CREATE OR REPLACE FUNCTION obtener_nombre_ocupacion (
    p_id_ocupacion IN NUMBER
) RETURN VARCHAR2 IS
    v_nombre_ocupacion VARCHAR2(100);
BEGIN
    SELECT nombre_ocupacion
    INTO v_nombre_ocupacion
    FROM Ocupaciones
    WHERE id_ocupacion = p_id_ocupacion;

    RETURN v_nombre_ocupacion;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'Ocupación no encontrada';
    WHEN OTHERS THEN
        RETURN 'Error: ' || SQLERRM;
END;
/

--12. Funcion que cuenta el numero de productos en una categoria especifica
CREATE OR REPLACE FUNCTION contar_productos_categoria (
    p_id_categoria IN NUMBER
) RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_total
    FROM Productos
    WHERE id_categoria = p_id_categoria;

    RETURN v_total; 
END;
/

--13. Funcion que verifica si un proveedor existe en la base de datos
CREATE OR REPLACE FUNCTION existe_proveedor (
    p_id_proveedor IN NUMBER
) RETURN BOOLEAN IS
    v_total NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_total
    FROM Proveedor
    WHERE id_proveedor = p_id_proveedor;

    RETURN v_total > 0;
END;
/

--14. Funcion que devuelve el inventario total de un producto dado su ID
CREATE OR REPLACE FUNCTION obtener_inventario_producto (
    p_id_producto IN NUMBER
) RETURN NUMBER IS
    v_inventario NUMBER;
BEGIN
    SELECT inventario
    INTO v_inventario
    FROM Productos
    WHERE id_producto = p_id_producto;

    RETURN v_inventario;
END;
/

--15. Funcion para contar total de empleados
CREATE OR REPLACE FUNCTION contar_empleados
RETURN NUMBER IS
    v_num_empleados NUMBER;
BEGIN
    -- Contar el n mero total de empleados
    SELECT COUNT(*)
    INTO v_num_empleados
    FROM Empleados;

    RETURN v_num_empleados;
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0; -- En caso de error en la consulta
END;
/

--16. Funcion para obetener el salario por ocupacion
CREATE OR REPLACE FUNCTION obtener_salario_total_ocupacion(
    p_id_ocupacion IN NUMBER
) RETURN NUMBER IS
    v_total NUMBER;
BEGIN
    SELECT SUM(salario)
    INTO v_total
    FROM Empleados
    WHERE id_ocupacion = p_id_ocupacion;

    RETURN NVL(v_total, 0);
END obtener_salario_total_ocupacion;

/*------------------------PAQUETES--------------------------*/

-- KEISY --
--1. Paquete para servicios
CREATE OR REPLACE PACKAGE reservaciones_pkg IS
    FUNCTION calcular_total_servicios_general
    RETURN NUMBER;
END reservaciones_pkg;
/
-- Cuerpo del paquete
CREATE OR REPLACE PACKAGE BODY reservaciones_pkg IS
    FUNCTION calcular_total_servicios_general
    RETURN NUMBER IS
        v_total NUMBER;
    BEGIN
        -- Suma el monto total de todos los servicios
        SELECT SUM(monto_s)
        INTO v_total
        FROM Servicios;

        RETURN NVL(v_total, 0);
    END calcular_total_servicios_general;
END reservaciones_pkg;
/


-- 2. Paquete para ventas
CREATE OR REPLACE PACKAGE ventas_pkg IS
    FUNCTION obtener_total_ventas_producto(
        p_producto_id IN NUMBER
    ) RETURN NUMBER;

    FUNCTION calcular_promedio_ventas_producto(
        p_producto_id IN NUMBER
    ) RETURN NUMBER;
END ventas_pkg;
/
-- Cuerpo del paquete
CREATE OR REPLACE PACKAGE BODY ventas_pkg IS
    FUNCTION obtener_total_ventas_producto(
        p_producto_id IN NUMBER
    ) RETURN NUMBER IS
        v_total NUMBER;
    BEGIN
        SELECT SUM(total)
        INTO v_total
        FROM Ventas
        WHERE id_producto = p_producto_id;

        RETURN NVL(v_total, 0);
    END obtener_total_ventas_producto;

    FUNCTION calcular_promedio_ventas_producto(
        p_producto_id IN NUMBER
    ) RETURN NUMBER IS
        v_promedio NUMBER;
    BEGIN
        SELECT AVG(total)
        INTO v_promedio
        FROM Ventas
        WHERE id_producto = p_producto_id;

        RETURN NVL(v_promedio, 0);
    END calcular_promedio_ventas_producto;
END ventas_pkg;
/



--3. Paquete para reservaciones
CREATE OR REPLACE PACKAGE reservaciones_pkg IS
    FUNCTION obtener_cantidad_reservaciones_cliente(
        p_cliente_id IN NUMBER
    ) RETURN NUMBER;

    FUNCTION obtener_cantidad_reservaciones_fecha(
        p_dia IN DATE
    ) RETURN NUMBER;

    FUNCTION obtener_detalles_reservacion(
        p_reservacion_id IN NUMBER
    ) RETURN VARCHAR2;
END reservaciones_pkg;
/
-- Cuerpo del paquete
CREATE OR REPLACE PACKAGE BODY reservaciones_pkg IS
    FUNCTION obtener_cantidad_reservaciones_cliente(
        p_cliente_id IN NUMBER
    ) RETURN NUMBER IS
        v_cantidad NUMBER;
    BEGIN
        SELECT COUNT(*)
        INTO v_cantidad
        FROM Reservaciones
        WHERE id_cliente = p_cliente_id;

        RETURN NVL(v_cantidad, 0);
    END obtener_cantidad_reservaciones_cliente;

    FUNCTION obtener_cantidad_reservaciones_fecha(
        p_dia IN DATE
    ) RETURN NUMBER IS
        v_cantidad NUMBER;
    BEGIN
        SELECT COUNT(*)
        INTO v_cantidad
        FROM Reservaciones
        WHERE dia = p_dia;

        RETURN NVL(v_cantidad, 0);
    END obtener_cantidad_reservaciones_fecha;

    FUNCTION obtener_detalles_reservacion(
        p_reservacion_id IN NUMBER
    ) RETURN VARCHAR2 IS
        v_detalles VARCHAR2(4000);
    BEGIN
        SELECT 'ID: ' || id_reservacion || ', Cliente ID: ' || id_cliente || ', Cantidad: ' || cantidad || ', D a: ' || dia
        INTO v_detalles
        FROM Reservaciones
        WHERE id_reservacion = p_reservacion_id;

        RETURN v_detalles;
    END obtener_detalles_reservacion;
END reservaciones_pkg;
/



--4. Paquete reservaciones
CREATE OR REPLACE PACKAGE reservaciones_totales_pkg IS
    FUNCTION obtener_total_reservaciones RETURN NUMBER;
    FUNCTION obtener_total_reservaciones_por_cliente(
        p_cliente_id IN NUMBER
    ) RETURN NUMBER;
END reservaciones_totales_pkg;
/
--cuerpo del paquete
CREATE OR REPLACE PACKAGE BODY reservaciones_totales_pkg IS
    FUNCTION obtener_total_reservaciones RETURN NUMBER IS
        v_total_reservaciones NUMBER;
    BEGIN
        SELECT COUNT(*)
        INTO v_total_reservaciones
        FROM Reservaciones;

        RETURN v_total_reservaciones;
    END obtener_total_reservaciones;

    FUNCTION obtener_total_reservaciones_por_cliente(
        p_cliente_id IN NUMBER
    ) RETURN NUMBER IS
        v_total_reservaciones NUMBER;
    BEGIN
        SELECT COUNT(*)
        INTO v_total_reservaciones
        FROM Reservaciones
        WHERE id_cliente = p_cliente_id;

        RETURN v_total_reservaciones;
    END obtener_total_reservaciones_por_cliente;
END reservaciones_totales_pkg;
/

-- JOHEL --
-- 5. Paquete para manejar operaciones de categorías
CREATE OR REPLACE PACKAGE pkg_categorias AS
    PROCEDURE sp_insert_categoria(p_nombre_categoria IN VARCHAR2);
    PROCEDURE sp_update_categoria(p_id_categoria IN NUMBER, p_nombre_categoria IN VARCHAR2);
    PROCEDURE sp_delete_categoria(p_id_categoria IN NUMBER);
    PROCEDURE sp_listar_categorias(p_categorias OUT SYS_REFCURSOR);
END pkg_categorias;
/

CREATE OR REPLACE PACKAGE BODY pkg_categorias AS
    PROCEDURE sp_insert_categoria(p_nombre_categoria IN VARCHAR2) IS
    BEGIN
        INSERT INTO Categorias (nombre_categoria)
        VALUES (p_nombre_categoria);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al insertar en la tabla Categorias: ' || SQLERRM);
    END;

    PROCEDURE sp_update_categoria(p_id_categoria IN NUMBER, p_nombre_categoria IN VARCHAR2) IS
    BEGIN
        UPDATE Categorias
        SET nombre_categoria = p_nombre_categoria
        WHERE id_categoria = p_id_categoria;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al actualizar en la tabla Categorias: ' || SQLERRM);
    END;

    PROCEDURE sp_delete_categoria(p_id_categoria IN NUMBER) IS
    BEGIN
        DELETE FROM Categorias
        WHERE id_categoria = p_id_categoria;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al eliminar en la tabla Categorias: ' || SQLERRM);
    END;

    PROCEDURE sp_listar_categorias(p_categorias OUT SYS_REFCURSOR) IS
    BEGIN
        OPEN p_categorias FOR
        SELECT id_categoria, nombre_categoria
        FROM Categorias;
    END;
END pkg_categorias;
/

-- 6. Paquete para manejar operaciones de clientes
CREATE OR REPLACE PACKAGE pkg_clientes AS
    PROCEDURE sp_insert_cliente(p_nombre_cliente IN VARCHAR2, p_telefono IN VARCHAR2, p_numero IN VARCHAR2);
    PROCEDURE sp_update_cliente(p_id_cliente IN NUMBER, p_nombre_cliente IN VARCHAR2, p_telefono IN VARCHAR2, p_numero IN VARCHAR2);
    PROCEDURE sp_delete_cliente(p_id_cliente IN NUMBER);
    PROCEDURE sp_listar_clientes(p_clientes OUT SYS_REFCURSOR);
END pkg_clientes;
/

CREATE OR REPLACE PACKAGE BODY pkg_clientes AS
    PROCEDURE sp_insert_cliente(p_nombre_cliente IN VARCHAR2, p_telefono IN VARCHAR2, p_numero IN VARCHAR2) IS
    BEGIN
        INSERT INTO Clientes (nombre_cliente, telefono, numero)
        VALUES (p_nombre_cliente, p_telefono, p_numero);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al insertar en la tabla Clientes: ' || SQLERRM);
    END;

    PROCEDURE sp_update_cliente(p_id_cliente IN NUMBER, p_nombre_cliente IN VARCHAR2, p_telefono IN VARCHAR2, p_numero IN VARCHAR2) IS
    BEGIN
        UPDATE Clientes
        SET nombre_cliente = p_nombre_cliente,
            telefono = p_telefono,
            numero = p_numero
        WHERE id_cliente = p_id_cliente;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al actualizar en la tabla Clientes: ' || SQLERRM);
    END;

    PROCEDURE sp_delete_cliente(p_id_cliente IN NUMBER) IS
    BEGIN
        DELETE FROM Clientes
        WHERE id_cliente = p_id_cliente;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al eliminar en la tabla Clientes: ' || SQLERRM);
    END;

    PROCEDURE sp_listar_clientes(p_clientes OUT SYS_REFCURSOR) IS
    BEGIN
        OPEN p_clientes FOR
        SELECT id_cliente, nombre_cliente, telefono, numero
        FROM Clientes;
    END;
END pkg_clientes;
/

-- 7. Paquete para manejar operaciones de empleados
CREATE OR REPLACE PACKAGE pkg_empleados AS
    PROCEDURE sp_insert_empleado(p_id_ocupacion IN NUMBER, p_nombre_empleado IN VARCHAR2, p_apellido IN VARCHAR2, p_telefono IN VARCHAR2, p_salario IN NUMBER);
    PROCEDURE sp_update_empleado(p_id_empleado IN NUMBER, p_id_ocupacion IN NUMBER, p_nombre_empleado IN VARCHAR2, p_apellido IN VARCHAR2, p_telefono IN VARCHAR2, p_salario IN NUMBER);
    PROCEDURE sp_delete_empleado(p_id_empleado IN NUMBER);
    PROCEDURE sp_listar_empleados(p_empleados OUT SYS_REFCURSOR);
END pkg_empleados;
/

CREATE OR REPLACE PACKAGE BODY pkg_empleados AS
    PROCEDURE sp_insert_empleado(p_id_ocupacion IN NUMBER, p_nombre_empleado IN VARCHAR2, p_apellido IN VARCHAR2, p_telefono IN VARCHAR2, p_salario IN NUMBER) IS
    BEGIN
        INSERT INTO Empleados (id_ocupacion, nombre_empleado, apellido, telefono, salario)
        VALUES (p_id_ocupacion, p_nombre_empleado, p_apellido, p_telefono, p_salario);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al insertar en la tabla Empleados: ' || SQLERRM);
    END;

    PROCEDURE sp_update_empleado(p_id_empleado IN NUMBER, p_id_ocupacion IN NUMBER, p_nombre_empleado IN VARCHAR2, p_apellido IN VARCHAR2, p_telefono IN VARCHAR2, p_salario IN NUMBER) IS
    BEGIN
        UPDATE Empleados
        SET id_ocupacion = p_id_ocupacion,
            nombre_empleado = p_nombre_empleado,
            apellido = p_apellido,
            telefono = p_telefono,
            salario = p_salario
        WHERE id_empleado = p_id_empleado;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al actualizar en la tabla Empleados: ' || SQLERRM);
    END;

    PROCEDURE sp_delete_empleado(p_id_empleado IN NUMBER) IS
    BEGIN
        DELETE FROM Empleados
        WHERE id_empleado = p_id_empleado;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al eliminar en la tabla Empleados: ' || SQLERRM);
    END;

    PROCEDURE sp_listar_empleados(p_empleados OUT SYS_REFCURSOR) IS
    BEGIN
        OPEN p_empleados FOR
        SELECT id_empleado, nombre_empleado, apellido, telefono, salario
        FROM Empleados;
    END;
END pkg_empleados;
/

-- 8. Paquete para manejar operaciones de proveedores
CREATE OR REPLACE PACKAGE pkg_proveedores AS
    PROCEDURE sp_insert_proveedor(
        p_nombre_proveedor IN VARCHAR2,
        p_correo IN VARCHAR2,
        p_contacto IN VARCHAR2,
        p_direccion IN VARCHAR2
    );
    PROCEDURE sp_update_proveedor(
        p_id_proveedor IN NUMBER,
        p_nombre_proveedor IN VARCHAR2,
        p_correo IN VARCHAR2,
        p_contacto IN VARCHAR2,
        p_direccion IN VARCHAR2
    );
    PROCEDURE sp_delete_proveedor(
        p_id_proveedor IN NUMBER
    );
    PROCEDURE sp_listar_proveedores(
        p_proveedores OUT SYS_REFCURSOR
    );
END pkg_proveedores;
/

-- Cuerpo del paquete
CREATE OR REPLACE PACKAGE BODY pkg_proveedores AS
    PROCEDURE sp_insert_proveedor(
        p_nombre_proveedor IN VARCHAR2,
        p_correo IN VARCHAR2,
        p_contacto IN VARCHAR2,
        p_direccion IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO Proveedor (
            nombre_proveedor, 
            correo, 
            contacto, 
            direccion
        ) VALUES (
            p_nombre_proveedor, 
            p_correo, 
            p_contacto, 
            p_direccion
        );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al insertar en la tabla Proveedor: ' || SQLERRM);
    END;

    PROCEDURE sp_update_proveedor(
        p_id_proveedor IN NUMBER,
        p_nombre_proveedor IN VARCHAR2,
        p_correo IN VARCHAR2,
        p_contacto IN VARCHAR2,
        p_direccion IN VARCHAR2
    ) IS
    BEGIN
        UPDATE Proveedor
        SET nombre_proveedor = p_nombre_proveedor,
            correo = p_correo,
            contacto = p_contacto,
            direccion = p_direccion
        WHERE id_proveedor = p_id_proveedor;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al actualizar en la tabla Proveedor: ' || SQLERRM);
    END;

    PROCEDURE sp_delete_proveedor(
        p_id_proveedor IN NUMBER
    ) IS
    BEGIN
        DELETE FROM Proveedor
        WHERE id_proveedor = p_id_proveedor;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al eliminar en la tabla Proveedor: ' || SQLERRM);
    END;

    PROCEDURE sp_listar_proveedores(
        p_proveedores OUT SYS_REFCURSOR
    ) IS
    BEGIN
        OPEN p_proveedores FOR
        SELECT id_proveedor, nombre_proveedor, correo, contacto, direccion
        FROM Proveedor;
    END;
END pkg_proveedores;
/


--Juan Carlos--
--9. Paquete que agrupa procedimientos y funciones relacionados con ocupaciones
CREATE OR REPLACE PACKAGE ocupaciones_pkg IS
    PROCEDURE insertar_ocupacion(p_nombre_ocupacion IN VARCHAR2, p_cantidad_empleados IN NUMBER);
    PROCEDURE actualizar_ocupacion(p_id_ocupacion IN NUMBER, p_nombre_ocupacion IN VARCHAR2, p_cantidad_empleados IN NUMBER);
    PROCEDURE eliminar_ocupacion(p_id_ocupacion IN NUMBER);
    FUNCTION obtener_nombre_ocupacion(p_id_ocupacion IN NUMBER) RETURN VARCHAR2;
END ocupaciones_pkg;
/

CREATE OR REPLACE PACKAGE BODY ocupaciones_pkg IS
    PROCEDURE insertar_ocupacion(p_nombre_ocupacion IN VARCHAR2, p_cantidad_empleados IN NUMBER) IS
    BEGIN
        INSERT INTO Ocupaciones (nombre_ocupacion, cantidad_empleados)
        VALUES (p_nombre_ocupacion, p_cantidad_empleados);
        COMMIT;
    END insertar_ocupacion;

    PROCEDURE actualizar_ocupacion(p_id_ocupacion IN NUMBER, p_nombre_ocupacion IN VARCHAR2, p_cantidad_empleados IN NUMBER) IS
    BEGIN
        UPDATE Ocupaciones
        SET nombre_ocupacion = p_nombre_ocupacion,
            cantidad_empleados = p_cantidad_empleados
        WHERE id_ocupacion = p_id_ocupacion;
        COMMIT;
    END actualizar_ocupacion;

    PROCEDURE eliminar_ocupacion(p_id_ocupacion IN NUMBER) IS
    BEGIN
        DELETE FROM Ocupaciones
        WHERE id_ocupacion = p_id_ocupacion;
        COMMIT;
    END eliminar_ocupacion;

    FUNCTION obtener_nombre_ocupacion(p_id_ocupacion IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN obtener_nombre_ocupacion(p_id_ocupacion);
    END obtener_nombre_ocupacion;
END ocupaciones_pkg;
/

--10. Paquete que agrupa procedimientos y funciones relacionados con productos
CREATE OR REPLACE PACKAGE productos_pkg IS
    PROCEDURE insertar_producto(p_id_categoria IN NUMBER, p_id_proveedor IN NUMBER, p_nombre_producto IN VARCHAR2, p_inventario IN NUMBER);
    PROCEDURE actualizar_producto(p_id_producto IN NUMBER, p_id_categoria IN NUMBER, p_id_proveedor IN NUMBER, p_nombre_producto IN VARCHAR2, p_inventario IN NUMBER);
    PROCEDURE eliminar_producto(p_id_producto IN NUMBER);
    FUNCTION obtener_inventario_producto(p_id_producto IN NUMBER) RETURN NUMBER;
END productos_pkg;
/

CREATE OR REPLACE PACKAGE BODY productos_pkg IS
    PROCEDURE insertar_producto(p_id_categoria IN NUMBER, p_id_proveedor IN NUMBER, p_nombre_producto IN VARCHAR2, p_inventario IN NUMBER) IS
    BEGIN
        INSERT INTO Productos (id_categoria, id_proveedor, nombre_producto, inventario)
        VALUES (p_id_categoria, p_id_proveedor, p_nombre_producto, p_inventario);
        COMMIT;
    END insertar_producto;

    PROCEDURE actualizar_producto(p_id_producto IN NUMBER, p_id_categoria IN NUMBER, p_id_proveedor IN NUMBER, p_nombre_producto IN VARCHAR2, p_inventario IN NUMBER) IS
    BEGIN
        UPDATE Productos
        SET id_categoria = p_id_categoria,
            id_proveedor = p_id_proveedor,
            nombre_producto = p_nombre_producto,
            inventario = p_inventario
        WHERE id_producto = p_id_producto;
        COMMIT;
    END actualizar_producto;

    PROCEDURE eliminar_producto(p_id_producto IN NUMBER) IS
    BEGIN
        DELETE FROM Productos
        WHERE id_producto = p_id_producto;
        COMMIT;
    END eliminar_producto;

    FUNCTION obtener_inventario_producto(p_id_producto IN NUMBER) RETURN NUMBER IS
    BEGIN
        RETURN obtener_inventario_producto(p_id_producto);
    END obtener_inventario_producto;
END productos_pkg;
/

--11. Paquete que agrupa procedimientos y funciones relacionados con proveedores
CREATE OR REPLACE PACKAGE proveedores_pkg IS
    PROCEDURE insertar_proveedor(p_nombre_proveedor IN VARCHAR2, p_correo IN VARCHAR2, p_contacto IN VARCHAR2, p_direccion IN VARCHAR2);
    PROCEDURE actualizar_proveedor(p_id_proveedor IN NUMBER, p_nombre_proveedor IN VARCHAR2, p_correo IN VARCHAR2, p_contacto IN VARCHAR2, p_direccion IN VARCHAR2);
    PROCEDURE eliminar_proveedor(p_id_proveedor IN NUMBER);
    FUNCTION existe_proveedor(p_id_proveedor IN NUMBER) RETURN BOOLEAN;
END proveedores_pkg;
/

CREATE OR REPLACE PACKAGE BODY proveedores_pkg IS
    PROCEDURE insertar_proveedor(p_nombre_proveedor IN VARCHAR2, p_correo IN VARCHAR2, p_contacto IN VARCHAR2, p_direccion IN VARCHAR2) IS
    BEGIN
        INSERT INTO Proveedor (nombre_proveedor, correo, contacto, direccion)
        VALUES (p_nombre_proveedor, p_correo, p_contacto, p_direccion);
        COMMIT;
    END insertar_proveedor;

    PROCEDURE actualizar_proveedor(p_id_proveedor IN NUMBER, p_nombre_proveedor IN VARCHAR2, p_correo IN VARCHAR2, p_contacto IN VARCHAR2, p_direccion IN VARCHAR2) IS
    BEGIN
        UPDATE Proveedor
        SET nombre_proveedor = p_nombre_proveedor,
            correo = p_correo,
            contacto = p_contacto,
            direccion = p_direccion
        WHERE id_proveedor = p_id_proveedor;
        COMMIT;
    END actualizar_proveedor;

    PROCEDURE eliminar_proveedor(p_id_proveedor IN NUMBER) IS
    BEGIN
        DELETE FROM Proveedor
        WHERE id_proveedor = p_id_proveedor;
        COMMIT;
    END eliminar_proveedor;

    FUNCTION existe_proveedor(p_id_proveedor IN NUMBER) RETURN BOOLEAN IS
    BEGIN
        RETURN existe_proveedor(p_id_proveedor);
    END existe_proveedor;
END proveedores_pkg;
/

--12 Paquete que proporciona utilidades relacionadas con calculos y operaciones generales
-- Vuelve a crear el paquete y el cuerpo del paquete
CREATE OR REPLACE PACKAGE utilidades_pkg IS
    FUNCTION es_proveedor_valido(p_id_proveedor IN NUMBER) RETURN BOOLEAN;
    FUNCTION es_ocupacion_valida(p_id_ocupacion IN NUMBER) RETURN BOOLEAN;
    FUNCTION calcular_salario_total(p_id_ocupacion IN NUMBER) RETURN NUMBER;
END utilidades_pkg;
/

CREATE OR REPLACE PACKAGE BODY utilidades_pkg IS
    FUNCTION es_proveedor_valido(p_id_proveedor IN NUMBER) RETURN BOOLEAN IS
    BEGIN
        RETURN existe_proveedor(p_id_proveedor);
    END es_proveedor_valido;

    FUNCTION es_ocupacion_valida(p_id_ocupacion IN NUMBER) RETURN BOOLEAN IS
    BEGIN
        RETURN obtener_nombre_ocupacion(p_id_ocupacion) IS NOT NULL;
    END es_ocupacion_valida;

    FUNCTION calcular_salario_total(p_id_ocupacion IN NUMBER) RETURN NUMBER IS
    BEGIN
        RETURN obtener_salario_total_ocupacion(p_id_ocupacion);
    END calcular_salario_total;
END utilidades_pkg;
/

